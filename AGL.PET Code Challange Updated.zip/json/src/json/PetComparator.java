package json;

import java.util.Comparator;

public class PetComparator implements Comparator<Pet> {
	public int compare(Pet one, Pet two) {
		return one.getName().compareTo(two.getName());
	}
}
