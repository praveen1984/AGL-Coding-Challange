package json;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

/**
 * @author Crunchify.com
 * 
 */

public class JsonService {

	public static void main(String[] args) {
		callURL("http://agl-developer-test.azurewebsites.net/people.json");
	}

	public static void callURL(String myURL) {

		System.out.println("URL for JSON Service:\n" + myURL + "\n\n");

		// Calling JSON service for response--------------
		StringBuilder sb = new StringBuilder();
		URLConnection urlConn = null;
		InputStreamReader in = null;
		try {
			URL url = new URL(myURL);
			urlConn = url.openConnection();
			if (urlConn != null)
				urlConn.setReadTimeout(60 * 1000);
			if (urlConn != null && urlConn.getInputStream() != null) {
				in = new InputStreamReader(urlConn.getInputStream(),
						Charset.defaultCharset());
				BufferedReader bufferedReader = new BufferedReader(in);
				if (bufferedReader != null) {
					int cp;
					while ((cp = bufferedReader.read()) != -1) {
						sb.append((char) cp);
					}
					bufferedReader.close();
				}
			}
			in.close();
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling URL:" + myURL,
					e);
		}

		System.out.println("JSON response received from service:\n" + sb
				+ "\n\n");

		// Parsing of Json Response---------
		JsonParser jsonParser = new JsonParser();
		JsonArray jsonArray = (JsonArray) jsonParser.parse(sb.toString());
		Owner ownerObject = null;
		ArrayList<Pet> petsWithMaleOwner = new ArrayList<Pet>();
		ArrayList<Pet> petsWithFemaleOwner = new ArrayList<Pet>();
		for (int i = 0; i < jsonArray.size(); i++) {
			Gson gson = new Gson();

			ownerObject = gson.fromJson(jsonArray.get(i).toString(),
					Owner.class);
			ArrayList<Pet> pets = null;
			if (ownerObject.getPets() != null) {
				pets = ownerObject.getPets();
				if (ownerObject.getGender().equalsIgnoreCase("Male")) {
					for (int j = 0; j < pets.size(); j++) {
						petsWithMaleOwner.add(pets.get(j));
					}
				} else if (ownerObject.getGender().equalsIgnoreCase("Female")) {
					for (int j = 0; j < pets.size(); j++) {
						petsWithFemaleOwner.add(pets.get(j));
					}
				}

			}
		}

		// Sorting pets----------------------------
		PetComparator petComparator = new PetComparator();
		Collections.sort(petsWithMaleOwner, petComparator);
		Collections.sort(petsWithFemaleOwner, petComparator);

		// Printing Output
		System.out.println("Cats with Male Owner:");
		for (Pet pet : petsWithMaleOwner) {
			if (pet.getType().equalsIgnoreCase("Cat"))
				System.out.println(pet.toString());
		}
		System.out.println("\n\nCats with Female Owner:");
		for (Pet pet : petsWithFemaleOwner) {
			if (pet.getType().equalsIgnoreCase("Cat"))
				System.out.println(pet.toString());
		}

	}
}
