package json;

import com.google.gson.annotations.SerializedName;
public class JsonResponse {
 
    @SerializedName("name")
    private String name;
    @SerializedName("gender")
    private String gender;
    @SerializedName("age")
    private String age;
    @SerializedName("pets")
    private String pets;
 
    public JsonResponse(String name, String gender, String age, String pets) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.pets = pets;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getPets() {
		return pets;
	}

	public void setPets(String pets) {
		this.pets = pets;
	}
}
