package json;

import java.awt.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author Crunchify.com
 * 
 */

public class JsonService {

	public static void main(String[] args) throws JsonParseException,
			JsonMappingException, IOException {
		System.out
				.println("\nOutput: \n"
						+ callURL("http://agl-developer-test.azurewebsites.net/people.json"));
	}

	public static String callURL(String myURL) throws JsonParseException,
			JsonMappingException, IOException {
		System.out.println("Requeted URL:" + myURL);
		StringBuilder sb = new StringBuilder();
		URLConnection urlConn = null;
		InputStreamReader in = null;
		try {
			URL url = new URL(myURL);
			urlConn = url.openConnection();
			if (urlConn != null)
				urlConn.setReadTimeout(60 * 1000);
			if (urlConn != null && urlConn.getInputStream() != null) {
				in = new InputStreamReader(urlConn.getInputStream(),
						Charset.defaultCharset());
				BufferedReader bufferedReader = new BufferedReader(in);
				if (bufferedReader != null) {
					int cp;
					while ((cp = bufferedReader.read()) != -1) {
						sb.append((char) cp);
					}
					bufferedReader.close();
				}
			}
			in.close();
		} catch (Exception e) {
			throw new RuntimeException("Exception while calling URL:" + myURL,
					e);
		}

		JsonParser jsonParser = new JsonParser();
		JsonArray jsonArray = (JsonArray) jsonParser.parse(sb.toString());
		Owner ownerObject = null;
		ArrayList<Pet> petsWithMaleOwner = new ArrayList<Pet>();
		ArrayList<Pet> petsWithFemaleOwner = new ArrayList<Pet>();
		for (int i = 0; i < jsonArray.size(); i++) {
			Gson gson = new Gson();

			ownerObject = gson.fromJson(jsonArray.get(i).toString(),
					Owner.class);
			ArrayList<Pet> pets = null;
			if (ownerObject.getPets() != null) {
				pets = ownerObject.getPets();
				if (ownerObject.getGender().equalsIgnoreCase("Male")) {
					for (int j = 0; j < pets.size(); j++) {
						if (pets.get(j).getType().equalsIgnoreCase("Cat")) {
							petsWithMaleOwner.add(pets.get(j));
						}
					}
				} else if (ownerObject.getGender().equalsIgnoreCase("Female")) {
					for (int j = 0; j < pets.size(); j++) {
						if (pets.get(j).getType().equalsIgnoreCase("Cat")) {
							petsWithFemaleOwner.add(pets.get(j));
						}
					}
				}

			}
		}

		System.out.println("Cats with Male Owner:" + petsWithMaleOwner);
		System.out.println("Cats with Female Owner:" + petsWithFemaleOwner);

		return sb.toString();
	}
}
